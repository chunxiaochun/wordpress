<?php

define('EmpireBak_VERSION','2010');

define('EmpireBak_LASTTIME','200911251030');

define('EmpireBak_UPDATE','1');

?>