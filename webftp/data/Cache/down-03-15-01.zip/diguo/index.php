<?php
require('class/connect.php');
require('class/functions.php');
require LoadAdminTemp('eindex.php');
?>