<?php
//MYSQL Char
$dbcharr=Array(
	'0'=>'gbk',
	'1'=>'utf8',
	'2'=>'gb2312',
	'3'=>'big5',
	'4'=>'latin1'
	);

//Language
$langcharr=Array(
	'0'=>'gb,gb2312,Chinese simplified',
	'1'=>'gbutf8,utf-8,Chinese simplified',
	'2'=>'big5,big5,Chinese traditional',
	'3'=>'big5utf8,utf-8,Chinese traditional'
	);
?>